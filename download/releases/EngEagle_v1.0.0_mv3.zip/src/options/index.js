true&&(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
}());

const wordCountEl = document.getElementById("word-count");
const dictStatusEl = document.getElementById("dict-status");
const settingsToggle = document.getElementById("settings-toggle");
const settingsContent = document.getElementById("settings-content");
const deepLApiKeyInput = document.getElementById("deepl-api-key");
const btnToggleKey = document.getElementById("btn-toggle-key");
const btnTestDeepL = document.getElementById("btn-test-deepl");
const btnSaveDeepL = document.getElementById("btn-save-deepl");
const deepLStatus = document.getElementById("deepl-status");
const deepLUsage = document.getElementById("deepl-usage");
const usageCount = document.getElementById("usage-count");
const usageLimit = document.getElementById("usage-limit");
const searchInput = document.getElementById("search-input");
const searchClear = document.getElementById("search-clear");
const vocabBody = document.getElementById("vocab-body");
const emptyState = document.getElementById("empty-state");
const loadingState = document.getElementById("loading-state");
const undoToast = document.getElementById("undo-toast");
const undoMessage = undoToast.querySelector(".undo-message");
const btnUndo = document.getElementById("btn-undo");
const addModal = document.getElementById("add-modal");
const addForm = document.getElementById("add-form");
const btnAdd = document.getElementById("btn-add");
const btnCancel = document.getElementById("btn-cancel");
const btnExport = document.getElementById("btn-export");
const exportMenu = document.getElementById("export-menu");
const btnImport = document.getElementById("btn-import");
const fileImport = document.getElementById("file-import");
let allEntries = [];
let filteredEntries = [];
let deletedEntry = null;
let undoTimeout = null;
let currentSort = { key: "created_at", asc: false };
const posLabels = {
  "noun": "명사",
  "verb": "동사",
  "adj": "형용사",
  "adv": "부사",
  "prep": "전치사",
  "conj": "접속사",
  "pron": "대명사",
  "interj": "감탄사",
  "other": "기타"
};
async function init() {
  await loadStatus();
  await loadVocabulary();
  await loadDeepLConfig();
  setupEventListeners();
  setupDeepLEventListeners();
}
async function loadStatus() {
  try {
    const response = await chrome.runtime.sendMessage({ type: "STATUS" });
    if (response.success) {
      dictStatusEl.textContent = response.dictionaryLoaded ? "정상" : "오류";
      dictStatusEl.style.color = response.dictionaryLoaded ? "#3fb950" : "#f85149";
    }
  } catch (error) {
    console.error("Status load failed:", error);
    dictStatusEl.textContent = "오류";
    dictStatusEl.style.color = "#f85149";
  }
}
async function loadVocabulary() {
  loadingState.style.display = "block";
  emptyState.style.display = "none";
  vocabBody.innerHTML = "";
  try {
    const response = await chrome.runtime.sendMessage({ type: "GET_ALL" });
    if (response.success) {
      allEntries = response.entries;
      wordCountEl.textContent = allEntries.length.toString();
      filterAndRender();
    }
  } catch (error) {
    console.error("Vocabulary load failed:", error);
  } finally {
    loadingState.style.display = "none";
  }
}
function filterAndRender() {
  const query = searchInput.value.toLowerCase().trim();
  if (query) {
    filteredEntries = allEntries.filter(
      (entry) => entry.word.toLowerCase().startsWith(query) || entry.lemma.toLowerCase().startsWith(query) || entry.meanings.some((m) => m.includes(query))
    );
    searchClear.style.display = "block";
  } else {
    filteredEntries = [...allEntries];
    searchClear.style.display = "none";
  }
  sortEntries();
  renderTable();
}
function sortEntries() {
  const { key, asc } = currentSort;
  filteredEntries.sort((a, b) => {
    let valA;
    let valB;
    switch (key) {
      case "word":
        valA = a.word.toLowerCase();
        valB = b.word.toLowerCase();
        break;
      case "freq":
        valA = a.freq;
        valB = b.freq;
        break;
      case "created_at":
      default:
        valA = a.created_at;
        valB = b.created_at;
    }
    if (valA < valB) return asc ? -1 : 1;
    if (valA > valB) return asc ? 1 : -1;
    return 0;
  });
}
function renderTable() {
  vocabBody.innerHTML = "";
  if (filteredEntries.length === 0) {
    emptyState.style.display = "block";
    return;
  }
  emptyState.style.display = "none";
  for (const entry of filteredEntries) {
    const tr = document.createElement("tr");
    tr.dataset.id = entry.id;
    const posLabel = posLabels[entry.pos] || entry.pos;
    const meanings = entry.meanings.join(", ");
    const date = formatDate(entry.created_at);
    tr.innerHTML = `
      <td class="col-word">
        <div class="word-cell">
          <span class="word-text">${escapeHtml(entry.word)}</span>
          <span class="word-pos">${escapeHtml(posLabel)}</span>
        </div>
      </td>
      <td class="col-meaning">
        <span class="meaning-cell">${escapeHtml(meanings)}</span>
      </td>
      <td class="col-example">
        <span class="example-cell">${escapeHtml(entry.example)}</span>
      </td>
      <td class="col-freq">
        <span class="freq-cell">${entry.freq}</span>
      </td>
      <td class="col-date">
        <span class="date-cell">${date}</span>
      </td>
      <td class="col-actions">
        <button class="btn btn-danger btn-delete" title="삭제">🗑</button>
      </td>
    `;
    vocabBody.appendChild(tr);
  }
}
function formatDate(timestamp) {
  const date = new Date(timestamp * 1e3);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}.${month}.${day}`;
}
function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}
function setupEventListeners() {
  searchInput.addEventListener("input", () => {
    filterAndRender();
  });
  searchClear.addEventListener("click", () => {
    searchInput.value = "";
    filterAndRender();
  });
  document.querySelectorAll("th[data-sort]").forEach((th) => {
    th.addEventListener("click", () => {
      const key = th.getAttribute("data-sort");
      if (currentSort.key === key) {
        currentSort.asc = !currentSort.asc;
      } else {
        currentSort.key = key;
        currentSort.asc = key === "word";
      }
      document.querySelectorAll("th[data-sort]").forEach((el) => {
        el.classList.remove("sort-asc", "sort-desc");
      });
      th.classList.add(currentSort.asc ? "sort-asc" : "sort-desc");
      filterAndRender();
    });
  });
  vocabBody.addEventListener("click", (e) => {
    const target = e.target;
    if (target.classList.contains("btn-delete")) {
      const tr = target.closest("tr");
      const id = tr.dataset.id;
      deleteEntry(id);
    }
  });
  btnUndo.addEventListener("click", undoDelete);
  btnAdd.addEventListener("click", () => {
    addModal.style.display = "flex";
    document.getElementById("add-word").focus();
  });
  btnCancel.addEventListener("click", () => {
    addModal.style.display = "none";
    addForm.reset();
  });
  addModal.querySelector(".modal-backdrop")?.addEventListener("click", () => {
    addModal.style.display = "none";
    addForm.reset();
  });
  addForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    await addNewWord();
  });
  btnExport.addEventListener("click", (e) => {
    e.stopPropagation();
    exportMenu.classList.toggle("show");
  });
  document.addEventListener("click", () => {
    exportMenu.classList.remove("show");
  });
  exportMenu.querySelectorAll("button").forEach((btn) => {
    btn.addEventListener("click", () => {
      const format = btn.dataset.format;
      exportData(format);
    });
  });
  btnImport.addEventListener("click", () => {
    fileImport.click();
  });
  fileImport.addEventListener("change", async () => {
    const file = fileImport.files?.[0];
    if (file) {
      await importData(file);
      fileImport.value = "";
    }
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && addModal.style.display === "flex") {
      addModal.style.display = "none";
      addForm.reset();
    }
  });
}
async function deleteEntry(id) {
  const entry = allEntries.find((e) => e.id === id);
  if (!entry) return;
  try {
    const response = await chrome.runtime.sendMessage({ type: "DELETE", id });
    if (response.success) {
      allEntries = allEntries.filter((e) => e.id !== id);
      wordCountEl.textContent = allEntries.length.toString();
      filterAndRender();
      showUndoToast(entry);
    }
  } catch (error) {
    console.error("Delete failed:", error);
  }
}
function showUndoToast(entry) {
  if (undoTimeout) {
    clearTimeout(undoTimeout);
  }
  deletedEntry = entry;
  undoMessage.textContent = `"${entry.word}" 삭제됨`;
  undoToast.style.display = "flex";
  undoTimeout = window.setTimeout(() => {
    hideUndoToast();
  }, 5e3);
}
function hideUndoToast() {
  undoToast.style.display = "none";
  deletedEntry = null;
  if (undoTimeout) {
    clearTimeout(undoTimeout);
    undoTimeout = null;
  }
}
async function undoDelete() {
  if (!deletedEntry) return;
  try {
    const response = await chrome.runtime.sendMessage({
      type: "RESTORE",
      entry: deletedEntry
    });
    if (response.success) {
      allEntries.push(deletedEntry);
      wordCountEl.textContent = allEntries.length.toString();
      filterAndRender();
      hideUndoToast();
    }
  } catch (error) {
    console.error("Undo failed:", error);
  }
}
async function addNewWord() {
  const word = document.getElementById("add-word").value.trim();
  const pos = document.getElementById("add-pos").value;
  const meaningsStr = document.getElementById("add-meanings").value.trim();
  const example = document.getElementById("add-example").value.trim();
  if (!word || !meaningsStr) return;
  const meanings = meaningsStr.split(",").map((m) => m.trim()).filter((m) => m);
  try {
    const response = await chrome.runtime.sendMessage({
      type: "SAVE",
      entry: {
        word,
        lemma: word.toLowerCase(),
        pos,
        meanings,
        example,
        source_url: ""
      }
    });
    if (response.success) {
      addModal.style.display = "none";
      addForm.reset();
      await loadVocabulary();
    }
  } catch (error) {
    console.error("Add failed:", error);
  }
}
async function exportData(format) {
  try {
    const response = await chrome.runtime.sendMessage({
      type: "EXPORT",
      format
    });
    if (response.success) {
      const blob = new Blob([response.data], {
        type: format === "json" ? "application/json" : "text/csv"
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `engeagle_vocabulary.${format}`;
      a.click();
      URL.revokeObjectURL(url);
    }
  } catch (error) {
    console.error("Export failed:", error);
  }
}
async function importData(file) {
  try {
    const text = await file.text();
    const response = await chrome.runtime.sendMessage({
      type: "IMPORT",
      data: text
    });
    if (response.success) {
      alert(`${response.imported}개의 단어를 가져왔습니다.`);
      await loadVocabulary();
    }
  } catch (error) {
    console.error("Import failed:", error);
    alert("가져오기 실패: 올바른 JSON 파일인지 확인하세요.");
  }
}
async function loadDeepLConfig() {
  try {
    const response = await chrome.runtime.sendMessage({ type: "DEEPL_LOAD_CONFIG" });
    if (response.success && response.config) {
      deepLApiKeyInput.value = response.config.apiKey || "";
    }
  } catch (error) {
    console.error("DeepL config load failed:", error);
  }
}
function setupDeepLEventListeners() {
  settingsToggle.addEventListener("click", () => {
    const isOpen = settingsContent.style.display !== "none";
    settingsContent.style.display = isOpen ? "none" : "block";
    settingsToggle.classList.toggle("open", !isOpen);
  });
  btnToggleKey.addEventListener("click", () => {
    const isPassword = deepLApiKeyInput.type === "password";
    deepLApiKeyInput.type = isPassword ? "text" : "password";
    btnToggleKey.textContent = isPassword ? "🙈" : "👁";
  });
  btnTestDeepL.addEventListener("click", testDeepLConnection);
  btnSaveDeepL.addEventListener("click", saveDeepLConfig);
}
async function testDeepLConnection() {
  const apiKey = deepLApiKeyInput.value.trim();
  if (!apiKey) {
    showDeepLStatus("API 키를 입력해주세요.", "error");
    return;
  }
  showDeepLStatus("연결 테스트 중...", "loading");
  btnTestDeepL.disabled = true;
  try {
    const response = await chrome.runtime.sendMessage({
      type: "DEEPL_TEST",
      config: { apiKey, useFreeApi: apiKey.endsWith(":fx") }
    });
    if (response.success) {
      showDeepLStatus("✅ " + response.message, "success");
      if (response.usage) {
        deepLUsage.style.display = "flex";
        usageCount.textContent = response.usage.character_count.toLocaleString();
        usageLimit.textContent = response.usage.character_limit.toLocaleString();
      }
    } else {
      showDeepLStatus("❌ " + response.message, "error");
      deepLUsage.style.display = "none";
    }
  } catch (error) {
    showDeepLStatus("❌ 테스트 실패", "error");
    console.error("DeepL test failed:", error);
  } finally {
    btnTestDeepL.disabled = false;
  }
}
async function saveDeepLConfig() {
  const apiKey = deepLApiKeyInput.value.trim();
  btnSaveDeepL.disabled = true;
  try {
    const response = await chrome.runtime.sendMessage({
      type: "DEEPL_SAVE_CONFIG",
      config: { apiKey, useFreeApi: apiKey.endsWith(":fx") }
    });
    if (response.success) {
      showDeepLStatus("✅ 설정이 저장되었습니다.", "success");
    } else {
      showDeepLStatus("❌ 저장 실패", "error");
    }
  } catch (error) {
    showDeepLStatus("❌ 저장 실패", "error");
    console.error("DeepL save failed:", error);
  } finally {
    btnSaveDeepL.disabled = false;
  }
}
function showDeepLStatus(message, type) {
  deepLStatus.textContent = message;
  deepLStatus.className = "deepl-status " + type;
  deepLStatus.style.display = "block";
}
init();
